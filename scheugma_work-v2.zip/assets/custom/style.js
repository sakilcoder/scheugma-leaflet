
var styleAoi = {
    weight: .9,
    color: "#e5aa70",
    opacity: .9,
    fillColor: "#000",
    fillOpacity: 0,
    // cursor: grab
}
var styleAoi2 = {
    weight: 3,
    color: "#a9a9a9",
    opacity: 1,
    fillColor: "#000",
    fillOpacity: 0
}
var styleBfLine = {
    weight: 6,
    color: "#a9a9a9",
    opacity: 1,
}
